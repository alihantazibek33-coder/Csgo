package dev.alihstudio.cs2stylemenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class CS2StyleMenuClient implements ClientModInitializer {
    private boolean wasPressed;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;

            boolean pressed = GLFW.glfwGetKey(
                    client.getWindow().getWindow(),
                    GLFW.GLFW_KEY_RIGHT_SHIFT
            ) == GLFW.GLFW_PRESS;

            if (pressed && !wasPressed && client.screen == null) {
                client.setScreen(new MainMenuScreen());
            }
            wasPressed = pressed;
        });
    }
}
