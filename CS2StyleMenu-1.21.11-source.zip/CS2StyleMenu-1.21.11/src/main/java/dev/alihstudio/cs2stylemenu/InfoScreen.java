package dev.alihstudio.cs2stylemenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class InfoScreen extends Screen {
    private final String title;
    private final String body;

    public InfoScreen(String title, String body) {
        super(Component.literal(title));
        this.title = title;
        this.body = body;
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("НАЗАД"), b ->
                minecraft.setScreen(new MainMenuScreen()))
                .bounds(width / 2 - 90, height - 48, 180, 24).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(0, 0, width, height, 0xD810141C);
        g.fill(0, 0, 7, height, 0xFF4DA3FF);
        g.fill(width / 2 - 190, 35, width / 2 + 190, height - 65, 0xCC202A38);
        g.drawCenteredString(font, title, width / 2, 52, 0xFFFFFFFF);
        String[] lines = body.split("\\n");
        int y = 95;
        for (String line : lines) {
            g.drawCenteredString(font, line, width / 2, y, 0xFFE6EDF5);
            y += 18;
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
