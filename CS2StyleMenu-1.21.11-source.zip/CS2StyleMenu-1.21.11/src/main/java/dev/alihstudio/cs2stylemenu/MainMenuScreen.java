package dev.alihstudio.cs2stylemenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class MainMenuScreen extends Screen {
    public MainMenuScreen() {
        super(Component.literal("CS2 STYLE"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 105;
        int top = this.height / 2 - 65;
        int w = 210;
        int h = 24;
        int gap = 7;

        addRenderableWidget(button("ИГРАТЬ", left, top, w, h,
                () -> minecraft.setScreen(new InfoScreen("ИГРАТЬ",
                        "Раздел игровых режимов будет добавлен следующим этапом."))));
        addRenderableWidget(button("ИНВЕНТАРЬ", left, top + (h + gap), w, h,
                () -> minecraft.setScreen(new InventoryScreen())));
        addRenderableWidget(button("ПРОФИЛЬ", left, top + 2 * (h + gap), w, h,
                () -> minecraft.setScreen(new InfoScreen("ПРОФИЛЬ",
                        "УРОВЕНЬ  1     ОПЫТ  0 / 100\n\nСТАТИСТИКА\nМатчи: 0    Победы: 0"))));
        addRenderableWidget(button("КОМНАТА", left, top + 3 * (h + gap), w, h,
                () -> minecraft.setScreen(new InfoScreen("КОМНАТА",
                        "Создание комнаты и приглашения друзей появятся в следующем этапе."))));
        addRenderableWidget(button("ТРЕНИРОВКА", left, top + 4 * (h + gap), w, h,
                () -> minecraft.setScreen(new InfoScreen("ТРЕНИРОВКА",
                        "Тренировочная площадка пока находится в разработке."))));
        addRenderableWidget(button("НАСТРОЙКИ", left, top + 5 * (h + gap), w, h,
                () -> minecraft.setScreen(new InfoScreen("НАСТРОЙКИ",
                        "Настройки интерфейса будут добавлены следующим этапом."))));
    }

    private Button button(String text, int x, int y, int w, int h, Runnable action) {
        return Button.builder(Component.literal(text), b -> action.run())
                .bounds(x, y, w, h).build();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(0, 0, width, height, 0xB810141C);
        g.fill(0, 0, 7, height, 0xFF4DA3FF);
        g.fill(width / 2 - 125, 25, width / 2 + 125, 78, 0xCC202A38);
        g.drawCenteredString(font, "CS2 STYLE", width / 2, 38, 0xFFFFFFFF);
        g.drawCenteredString(font, "ГЛАВНОЕ МЕНЮ", width / 2, 59, 0xFF79BFFF);
        g.drawString(font, "ПРОФИЛЬ: PLAYER", 18, 18, 0xFFE6EDF5);
        g.drawString(font, "УРОВЕНЬ 1", 18, 32, 0xFF79BFFF);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(font, "RIGHT SHIFT — ОТКРЫТЬ МЕНЮ", width / 2, height - 18, 0xFF9AA8B8);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
