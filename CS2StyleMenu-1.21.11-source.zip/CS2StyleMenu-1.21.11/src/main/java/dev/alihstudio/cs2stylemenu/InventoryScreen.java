package dev.alihstudio.cs2stylemenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class InventoryScreen extends Screen {
    public InventoryScreen() {
        super(Component.literal("ИНВЕНТАРЬ"));
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("ОБРАЗ ПЕРСОНАЖА"), b -> {})
                .bounds(width / 2 - 150, 105, 140, 26).build());
        addRenderableWidget(Button.builder(Component.literal("КОЛЛЕКЦИЯ"), b -> {})
                .bounds(width / 2 + 10, 105, 140, 26).build());
        addRenderableWidget(Button.builder(Component.literal("НАЗАД"), b ->
                minecraft.setScreen(new MainMenuScreen()))
                .bounds(width / 2 - 90, height - 48, 180, 24).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(0, 0, width, height, 0xD810141C);
        g.fill(0, 0, 7, height, 0xFF4DA3FF);
        g.fill(width / 2 - 190, 35, width / 2 + 190, height - 65, 0xCC202A38);
        g.drawCenteredString(font, "ИНВЕНТАРЬ", width / 2, 52, 0xFFFFFFFF);
        g.drawCenteredString(font, "ПРЕДМЕТЫ ВНЕШНЕГО ВИДА", width / 2, 155, 0xFF79BFFF);
        g.drawCenteredString(font, "Здесь будут карточки образов и предпросмотр персонажа.", width / 2, 180, 0xFFE6EDF5);
        g.drawCenteredString(font, "Косметические предметы можно будет просматривать и экипировать.", width / 2, 199, 0xFF9AA8B8);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
